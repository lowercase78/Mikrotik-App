cd && nohup warp -k eQ5f9i83-97g3ic6N-Rqp079x3 -b 0.0.0.0:8086 --scan > warp.log 2>&1 &
