nohup ck-client -s 91.107.191.9 -p 8080 -i 0.0.0.0 -l 2408 -c ck-warp.json -u > ck-client.log 2>&1 &

