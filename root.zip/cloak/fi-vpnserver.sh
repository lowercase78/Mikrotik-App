nohup ck-client -s 65.109.191.126 -p 8080 -i 0.0.0.0 -l 5555 -c /root/cloak/fi/vpnserver.json > ck-client.log 2>&1 &

