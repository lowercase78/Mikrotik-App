nohup ck-client -s 91.107.191.9 -p 8080 -i 0.0.0.0 -l 5555 -c ck-vpnserver.json > ck-client.log 2>&1 &
